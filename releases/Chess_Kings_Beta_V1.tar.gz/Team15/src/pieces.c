#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "pieces.h"
#include "player.h"
#include "square.h"
#include "moveList.h"

ChessPiece *createChessPiece(Color color, ChessPieceType pieceType, Square *square) //In square, pass in the square from the board (ex board[0][0] will be the square on A1)
{
  ChessPiece *newPiece = malloc(sizeof(ChessPiece));

  newPiece->square = square;
  newPiece->color = color;
  newPiece->Type = pieceType;

  square->thisSquaresPiece = newPiece;
  return newPiece;
}

void deleteChessPiece(ChessPiece *piece)
{
  assert(piece);
  free(piece);
  piece = NULL;
}

const Square *getPiecesSquare(const ChessPiece *piece)
{
  assert(piece);
  return piece->square;
}

void moveChessPiece(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{

  assert(piece);
  assert(endSquare);

  if (checkValidMove(piece, endSquare, gameBoard) == 1)
  {
    piece->square->thisSquaresPiece = NULL;
    endSquare->thisSquaresPiece = piece;
    piece->square = endSquare;
  }
  else if (checkValidMove(piece, endSquare, gameBoard) == 2) //if the move is a capture
  {
    piece->square->thisSquaresPiece = NULL;

    Player *player;
    if (piece->color == WHITE)
    {
      player = gameBoard->player2;
    }
    else
    {
      player = gameBoard->player1;
    }

    deletePlayerPiece(endSquare->thisSquaresPiece, player);
    endSquare->thisSquaresPiece = piece;
    piece->square = endSquare;
  }
  else
  {
    printf("This is not a valid move");
  }
}

int checkDestinationStatus(const ChessPiece *piece, const Square *destination)
{
  assert(piece);
  assert(destination);
  if (destination->thisSquaresPiece == NULL)
  {
    return 1;
  } //destination has no piece
  else if (destination->thisSquaresPiece->color == piece->color)
  {
    return -1;
  } //destination has the piece of the same color
  else if (abs(destination->thisSquaresPiece->color - piece->color) == 1)
  {
    return 0;
  } //destination has a piece with the opposite color
  else
  {
    return -2;
  }
}

int checkValidMove(const ChessPiece *piece, const Square *endSquare, const Board *chessBoard)
{
  if (checkDestinationStatus(piece, endSquare) == -1)
  {
    return 0;
  }

  int X[8] = {2, 1, -1, -2, -2, -1, 1, 2}; //possible relative positions a knight can move to
  int Y[8] = {1, 2, 2, 1, -1, -2, -2, -1};
  switch (piece->Type)
  {
  case PAWN:
    if (checkDestinationStatus(piece, endSquare) == 1) //if the end square is unoccupied
    {
      if ((((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == 2 && (piece->color == WHITE)) ||
           ((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == -2 && (piece->color == BLACK))) &&
          (getSquareXPos(endSquare) == getSquareXPos(getPiecesSquare(piece))))
      {
        return validPawnDoubleStep(piece, chessBoard);
      } //if its pawns first move and user wants to do a double step

      else if (((((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == 1) && (piece->color == WHITE)) ||
                (((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == -1) && (piece->color == BLACK))) &&
               (getSquareXPos(endSquare) == getSquareXPos(getPiecesSquare(piece))))
      {
        return 1;
      }
    }
    else if (checkDestinationStatus(piece, endSquare) == 0) //if it's a diagonal  pawn capture
    {
      if (((((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == 1) && (piece->color == WHITE)) ||
           (((getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) == -1) && (piece->color == BLACK))) &&
          (abs(getSquareXPos(endSquare) - getSquareXPos(getPiecesSquare(piece))) == 1))
      {
        return 2;
      }
    }
    return 0;
    break;

  case KNIGHT:

    if (checkDestinationStatus(piece, endSquare) != -1) //if the end square does not have a piece of the same color as the piece being moved
    {
      for (int i = 0; i < 8; ++i)
      {
        if (getSquareXPos(endSquare) == getSquareXPos(getPiecesSquare(piece)) + X[i] && getSquareYPos(endSquare) == getSquareYPos(getPiecesSquare(piece)) + Y[i])
        {
          if (checkDestinationStatus(piece, endSquare) == 0)
          {
            return 2;
          }
          else
          {
            return 1;
          }
        }
      }
    }
    return 0;
    break;

  case BISHOP:
    if (checkDestinationStatus(piece, endSquare) != -1 && checkDiagonalBlock(piece, endSquare, chessBoard) == 0)
    {
      if (abs(getSquareXPos(endSquare) - getSquareXPos(getPiecesSquare(piece))) == abs(getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece)))) //check for diagonal movement
      {
        if (checkDestinationStatus(piece, endSquare) == 0)
        {
          return 2;
        }
        else
        {
          return 1;
        }
      }
    }
    return 0;
    break;

  case ROOK:
    if (checkDestinationStatus(piece, endSquare) != -1)
    {
      if ((getSquareXPos(getPiecesSquare(piece)) == getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) != getSquareYPos(endSquare))) //check for vertical movement
      {
        if (checkVerticalBlock(piece, endSquare, chessBoard) == 0) //check no vertical block
        {
          if (checkDestinationStatus(piece, endSquare) == 0) //find if its a capture
            return 2;
          else
            return 1;
        }
      }
      else if ((getSquareXPos(getPiecesSquare(piece)) != getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) == getSquareYPos(endSquare))) //check for horizontal movement
      {
        if (checkHorizontalBlock(piece, endSquare, chessBoard) == 0) //check no horizontal block
        {
          if (checkDestinationStatus(piece, endSquare) == 0) //find if its a capture
            return 2;
          else
            return 1;
        }
      }
    }

    return 0;
    break;

  case QUEEN:
    if (checkDestinationStatus(piece, endSquare) != -1)
    {
      if ((getSquareXPos(getPiecesSquare(piece)) == getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) != getSquareYPos(endSquare))) //check for vertical movement
      {
        if (checkVerticalBlock(piece, endSquare, chessBoard) == 0) //check no vertical block
        {
          if (checkDestinationStatus(piece, endSquare) == 0) //find if its a capture
            return 2;
          else
            return 1;
        }
      }
      else if ((getSquareXPos(getPiecesSquare(piece)) != getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) == getSquareYPos(endSquare))) //check for horizontal movement
      {
        if (checkHorizontalBlock(piece, endSquare, chessBoard) == 0) //check no horizontal block
        {
          if (checkDestinationStatus(piece, endSquare) == 0) //find if its a capture
            return 2;
          else
            return 1;
        }
      }
      else if (abs(getSquareXPos(endSquare) - getSquareXPos(getPiecesSquare(piece))) == abs(getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece)))) //check for diagonal movement
      {
        if (checkDiagonalBlock(piece, endSquare, chessBoard) == 0) //check no diagonal block
        {
          if (checkDestinationStatus(piece, endSquare) == 0) //find if its a capture
            return 2;
          else
            return 1;
        }
      }
    }
    return 0;
    break;

  case KING:
    if (checkDestinationStatus(piece, endSquare) != -1)
    {
      if (abs(getSquareXPos(endSquare) - getSquareXPos(getPiecesSquare(piece))) <= 1 && abs(getSquareYPos(endSquare) - getSquareYPos(getPiecesSquare(piece))) <= 1) //check for one space  in any direction
      {
        if (checkDestinationStatus(piece, endSquare) == 0)
        {
          return 2;
        }

        else if (checkDestinationStatus(piece, endSquare) == 1)
        {
          return 1;
        }
      }
    }
    return 0;
    break;

  case NOPIECE:
    return -2; //input error
    break;
  }
  return -2;
}

int checkHorizontalBlock(const ChessPiece *piece, const Square *endSquare, const Board *gameBoard)
{
  if (getSquareXPos(endSquare) > getSquareXPos(getPiecesSquare(piece)))
  {
    int y = getSquareYPos(getPiecesSquare(piece));
    for (int i = getSquareXPos(getPiecesSquare(piece)) + 1; i < getSquareXPos(endSquare); ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[i][y]) != 1) // if the square at this spot in the board is not NULL (contains a piece)
      {
        return 1;
      }
    }
    return 0;
  }
  else if (getSquareXPos(endSquare) < getSquareXPos(getPiecesSquare(piece)))
  {
    int y = getSquareYPos(getPiecesSquare(piece));
    for (int i = getSquareXPos(getPiecesSquare(piece)) - 1; i > getSquareXPos(endSquare); --i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[i][y]) != 1) // if the square at this spot in the board is not NULL
      {
        return 1;
      }
    }
    return 0;
  }
  else
  {
    return -1; //error in input to function
  }
}

int checkVerticalBlock(const ChessPiece *piece, const Square *endSquare, const Board *gameBoard)
{
  if (getSquareYPos(endSquare) > getSquareYPos(getPiecesSquare(piece)))
  {
    int x = getSquareXPos(getPiecesSquare(piece));

    for (int i = getSquareYPos(getPiecesSquare(piece)) + 1; i < getSquareYPos(endSquare); ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[x][i]) != 1) // if the square at this spot in the board is not NULL (contains a piece)
      {
        return 1;
      }
    }

    return 0;
  }
  else if (getSquareYPos(endSquare) < getSquareYPos(getPiecesSquare(piece)))
  {
    int x = getSquareXPos(getPiecesSquare(piece));

    for (int i = getSquareYPos(getPiecesSquare(piece)) - 1; i > getSquareYPos(endSquare); --i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[x][i]) != 1) // if the square at this spot in the board is not NULL
      {
        return 1;
      }
    }

    return 0;
  }
  else
  {
    return -1; //error in input to function
  }
}

int checkDiagonalBlock(const ChessPiece *piece, const Square *endSquare, const Board *gameBoard)
{
  enum directions
  {
    TOPLEFT,
    BOTTOMLEFT,
    TOPRIGHT,
    BOTTOMRIGHT
  };

  int direction;
  /*Check the direciton of the movement from the piece to the endSquare */
  if ((getSquareXPos(getPiecesSquare(piece)) < getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) < getSquareYPos(endSquare)))
    direction = TOPRIGHT;
  else if ((getSquareXPos(getPiecesSquare(piece)) < getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) > getSquareYPos(endSquare)))
    direction = BOTTOMRIGHT;
  else if ((getSquareXPos(getPiecesSquare(piece)) > getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) < getSquareYPos(endSquare)))
    direction = TOPLEFT;
  else if ((getSquareXPos(getPiecesSquare(piece)) > getSquareXPos(endSquare)) && (getSquareYPos(getPiecesSquare(piece)) > getSquareYPos(endSquare)))
    direction = BOTTOMLEFT;
  else
    return -1; //error in input to function

  int pieceX = getSquareXPos(getPiecesSquare(piece)), pieceY = getSquareYPos(getPiecesSquare(piece));
  int squareX = getSquareXPos(endSquare);

  switch (direction)
  {
  case TOPRIGHT:
    for (int i = 0; i < abs(squareX - pieceX) - 1; ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[pieceX + 1 + i][pieceY + 1 + i]) != 1)
      {
        return 1;
      }
    }
    return 0;
    break;

  case BOTTOMRIGHT:
    for (int i = 0; i < abs(squareX - pieceX) - 1; ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[pieceX + 1 + i][pieceY - 1 - i]) != 1)
      {
        return 1;
      }
    }
    return 0;
    break;

  case TOPLEFT:
    for (int i = 0; i < abs(squareX - pieceX) - 1; ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[pieceX - 1 - i][pieceY + 1 + i]) != 1)
      {
        return 1;
      }
    }
    return 0;
    break;

  case BOTTOMLEFT:
    for (int i = 0; i < abs(squareX - pieceX) - 1; ++i)
    {
      if (checkDestinationStatus(piece, gameBoard->chessBoard[pieceX - 1 - i][pieceY - 1 - i]) != 1)
      {
        return 1;
      }
    }
    return 0;
    break;
  }
  return -1; //error in input to function
}

int validPawnDoubleStep(const ChessPiece *piece, const Board *chessBoard)
{
  if (piece->color == WHITE && getSquareYPos(piece->square) == 1)
  {
    if (getChessPiece(chessBoard->chessBoard[getSquareXPos(getPiecesSquare(piece))][3]) == NULL)
      return 1;
  }
  else if (piece->color == BLACK && getSquareYPos(piece->square) == 6)
  {
    if (getChessPiece(chessBoard->chessBoard[getSquareXPos(getPiecesSquare(piece))][4]) == NULL)
      return 1;
  }

  return 0;
}

int validPawnPromotion(const ChessPiece *piece)
{
  if (piece->color == WHITE && getSquareYPos(piece->square) == 7 && piece->Type == PAWN)
  {
    return 1;
  }
  else if (piece->color == BLACK && getSquareYPos(piece->square) == 0 && piece->Type == PAWN)
  {
    return 1;
  }

  return 0;
}

int kingChecked(ChessPiece *piece, Board *chessBoard, Player *opponent) //pass in a king piece, the game board, and a pointer to the opponent
{
  assert(piece);
  assert(chessBoard);
  assert(opponent);

  if (piece->Type != KING)
  {
    return -2; //error in piece type input
  }

  for (int i = 0; i < sizeof(opponent->playerPieces) / sizeof(opponent->playerPieces[0]); ++i)
  {
    if (opponent->playerPieces[i] == NULL)
    {
      continue;
    }
    else if (checkValidMove(opponent->playerPieces[i], piece->square, chessBoard) != 0)
    {
      return 1;
    }
  }
  return 0;
}

MoveList *getValidMoves(const ChessPiece *piece, const Board *gameBoard)
{

  MoveList *newMoveList = createMoveList();

  for (int x = 0; x < 8; ++x)
  {
    for (int y = 0; y < 8; ++y)
    {
      //if(gameBoard->chessBoard[x][y]->thisSquaresPiece != NULL){
      //printf("\nx: %d, y:  %d\n%d\n", x, y, gameBoard->chessBoard[x][y]->thisSquaresPiece->Type);
      if ((checkValidMove(piece, gameBoard->chessBoard[x][y], gameBoard) != 0))
      {
        appendMove(piece->square, gameBoard->chessBoard[x][y], newMoveList);
      }
      //}
    }
  }

  return newMoveList;
}

int validEnPassant(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{
	if (getChessPiece(endSquare) == NULL)		//checking if end square is empty
	{	//checking if endsquare is diagnol in any direction
		if (abs(getSquareXPos(endSquare)-getSquareXPos(getPiecesSquare(piece))) == 1 && abs(getSquareYPos(endSquare)-getSquareYPos(getPiecesSquare(piece))) == 1)
		{
			if (piece->color == WHITE)
			{
				ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)][getSquareYPos(endSquare)-1]);
				if (tempPiece->color == BLACK && tempPiece->Type == PAWN)
				{
					//if tempPiece just double stepped IDK HOW
					return 1;
				}
			}
			else if (piece->color == BLACK)
			{
				ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)][getSquareYPos(endSquare)+1]);
				if (tempPiece->color == WHITE && tempPiece->Type == PAWN)
				{
					//if tempPiece just double stepped IDK HOW
					return 1;
				}
			}
		}
	}
	return 0;
}

void captureEnPassant(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{
	moveChessPiece(piece, endSquare, gameBoard);		//move pawn diagonally to chosen square
	if (piece->color == WHITE)		//deletes/captures other pawn that just double stepped
			{
				ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)][getSquareYPos(endSquare)-1]);
				deleteChessPiece(tempPiece);

			}
	else if (piece->color == BLACK)
			{
				ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)][getSquareYPos(endSquare)+1]);
				deleteChessPiece(tempPiece);
			}
}

int validCastle(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{
	if(getSquareXPos(piece->square) == 4)		//checking for king in starting position
	{
		if (getChessPiece(endSquare) == NULL)		//checking if end square is empty
		{
			if (getSquareXPos(endSquare) > 4)		//checking for left or right castle
			{
				if (getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)-1][getSquareYPos(endSquare)]) == NULL)		//checking for no other pieces in the way
				{
					if(piece->color == WHITE)				//check if white or black king is castling
					{
						ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[7][0]);		//check if rook is in starting position
						if(tempPiece->Type == ROOK)
						{
							//check if king is not in check or avoiding check by moving past a square(IDK???)

							return 1;
						}
					}
					else if(piece->color == BLACK)
					{
						ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[7][7]);		//check if rook is in starting position
						if(tempPiece->Type == ROOK)
						{
							//check if king is not in check or avoiding check by moving past a square(IDK???)

							return 1;
						}
					}
				}
			}
			else if (getSquareXPos(endSquare) < 4)
			{
				if (getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare)+1][getSquareYPos(endSquare)]) == NULL)
				{
					if(piece->color == WHITE)				//check if white or black king is castling
					{
						ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[0][0]);		//check if rook is in starting position
						if(tempPiece->Type == ROOK)
						{
							//check if king is not in check or avoiding check by moving past a square(IDK???)
              return 1;
            }
          }
        }
      }
      else if (getSquareXPos(endSquare) < 4)
      {
        if (getChessPiece(gameBoard->chessBoard[getSquareXPos(endSquare) + 1][getSquareYPos(endSquare)]) == NULL)
        {
          if (piece->color == WHITE) //check if white or black king is castling
          {
            ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[0][0]); //check if rook is in starting position
            if (tempPiece->Type == ROOK)
            {
              //check if king is not in check or avoiding check by moving past a square(IDK???)

              return 1;
            }
          }
          else if (piece->color == BLACK)
          {
            ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[0][7]); //check if rook is in starting position
            if (tempPiece->Type == ROOK)
            {
              //check if king is not in check or avoiding check by moving past a square(IDK???)
              return 1;
            }
          }
        }
      }
    }
  }
  return 0;
}

void performCastle(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{
	moveChessPiece(piece, endSquare, gameBoard);		//move king piece over to chosen square(left 2 or right 2)

	if (getSquareXPos(endSquare) > 4)		//checking for left or right castle
	{
		if(piece->color == WHITE)				//check if white or black king is castling
		{
			ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[7][0]);		//set tempPiece to the correct rook so it can be moved
			moveChessPiece(tempPiece, gameBoard->chessBoard[getSquareXPos(endSquare)-1][0], gameBoard);		//move rook onto other side of king
		}
		else if(piece->color == BLACK)
		{
			ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[7][7]);
			moveChessPiece(tempPiece, gameBoard->chessBoard[getSquareXPos(endSquare)-1][7], gameBoard);

		}
	}
	else if (getSquareXPos(endSquare) < 4)
	{
		if(piece->color == WHITE)
		{
			ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[0][0]);
			moveChessPiece(tempPiece, gameBoard->chessBoard[getSquareXPos(endSquare)+1][0], gameBoard);

		}
		else if(piece->color == BLACK)
		{
			ChessPiece *tempPiece = getChessPiece(gameBoard->chessBoard[0][7]);
			moveChessPiece(tempPiece, gameBoard->chessBoard[getSquareXPos(endSquare)+1][7], gameBoard);

		}

	}
}

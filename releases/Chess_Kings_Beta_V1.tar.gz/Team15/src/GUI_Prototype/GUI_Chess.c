/***********************************************************
*
*A simple GTK example
*simple.c: show a 2x2 board and move the king by clicking
*author: Weiwei Chen
*initial version: 01/22/13 EECS22L Winter 2013
*
***********************************************************/

#include <gtk/gtk.h>
#include <stdlib.h>
#include <assert.h>
#include "GUI_Chess.h"
#include "../pieces.h"
#include "string.h"
#include "main-menu.h"
#include "../chessStructs.h"
#include "../board.h"
#include "../square.h"
#include "../player.h"
#include "../moveList.h"

/*Global Variables */
FILE *mLog;
int opp;
int set;

GtkWidget *window;
GtkWidget *fixed;
GtkWidget *chess_icon;
GtkWidget *table;

GtkWidget *promWin;
ChessPieceType *promoted;

GtkWidget *hisWin;
GtkWidget *scrollView;
GtkWidget *moveHistory;
GtkTextBuffer *history;
GtkTextIter iter;
GtkTextMark *update;

//enum is a user defined data type assigns names to integral constants
//enum is defined in the header file
//enum variable is GRID
//Board is an object of GRID instantiated below
//Black corresponds to 0 white to 1 and king to 2
enum GRID Game[8][8];
//variable Board[][] of type enum boolean is created
void MoveThePiece(int g_x, int g_y, int oldX, int oldY, Board *gameBoard);
void DrawBoard();

void InitBoard(Player *player2, Board *thisGameBoard)
{
        int i, j;
        for (i = 0; i < 8; i++)
        {
                for (j = 0; j < 8; j++)
                {
                        if ((i + j) % 2 == 0)
                        {
                                Game[i][j] = SWHITE;
                        }
                        else
                        {
                                Game[i][j] = SBLACK;
                        }
                }
        }

        if (set == 0)
        {
                Game[0][0] = BROOK;
                Game[1][0] = BKNIGHT;
                Game[2][0] = BBISHOP;
                Game[3][0] = BQUEEN;
                Game[4][0] = BKING;
                Game[5][0] = BBISHOP;
                Game[6][0] = BKNIGHT;
                Game[7][0] = BROOK;
                Game[0][1] = BPAWN;
                Game[1][1] = BPAWN;
                Game[2][1] = BPAWN;
                Game[3][1] = BPAWN;
                Game[4][1] = BPAWN;
                Game[5][1] = BPAWN;
                Game[6][1] = BPAWN;
                Game[7][1] = BPAWN;

                Game[0][7] = WROOK;
                Game[1][7] = WKNIGHT;
                Game[2][7] = WBISHOP;
                Game[3][7] = WQUEEN;
                Game[4][7] = WKING;
                Game[5][7] = WBISHOP;
                Game[6][7] = WKNIGHT;
                Game[7][7] = WROOK;
                Game[0][6] = WPAWN;
                Game[1][6] = WPAWN;
                Game[2][6] = WPAWN;
                Game[3][6] = WPAWN;
                Game[4][6] = WPAWN;
                Game[5][6] = WPAWN;
                Game[6][6] = WPAWN;
                Game[7][6] = WPAWN;
        }
        else
        {
                Game[0][7] = BROOK;
                Game[1][7] = BKNIGHT;
                Game[2][7] = BBISHOP;
                Game[3][7] = BQUEEN;
                Game[4][7] = BKING;
                Game[5][7] = BBISHOP;
                Game[6][7] = BKNIGHT;
                Game[7][7] = BROOK;
                Game[0][6] = BPAWN;
                Game[1][6] = BPAWN;
                Game[2][6] = BPAWN;
                Game[3][6] = BPAWN;
                Game[4][6] = BPAWN;
                Game[5][6] = BPAWN;
                Game[6][6] = BPAWN;
                Game[7][6] = BPAWN;

                Game[0][0] = WROOK;
                Game[1][0] = WKNIGHT;
                Game[2][0] = WBISHOP;
                Game[3][0] = WQUEEN;
                Game[4][0] = WKING;
                Game[5][0] = WBISHOP;
                Game[6][0] = WKNIGHT;
                Game[7][0] = WROOK;
                Game[0][1] = WPAWN;
                Game[1][1] = WPAWN;
                Game[2][1] = WPAWN;
                Game[3][1] = WPAWN;
                Game[4][1] = WPAWN;
                Game[5][1] = WPAWN;
                Game[6][1] = WPAWN;
                Game[7][1] = WPAWN;
        }
}

void ResetBoard()
{

        int i, j;
        for (i = 0; i < 8; i++)
        {
                for (j = 0; j < 8; j++)
                {
                        if ((i + j) % 2 == 0)
                        {
                                Game[i][j] = SWHITE;
                        }
                        else
                        {
                                Game[i][j] = SBLACK;
                        }
                }
        }

        Game[0][0] = BROOK;
        Game[1][0] = BKNIGHT;
        Game[2][0] = BBISHOP;
        Game[3][0] = BQUEEN;
        Game[4][0] = BKING;
        Game[5][0] = BBISHOP;
        Game[6][0] = BKNIGHT;
        Game[7][0] = BROOK;
        Game[0][1] = BPAWN;
        Game[1][1] = BPAWN;
        Game[2][1] = BPAWN;
        Game[3][1] = BPAWN;
        Game[4][1] = BPAWN;
        Game[5][1] = BPAWN;
        Game[6][1] = BPAWN;
        Game[7][1] = BPAWN;

        Game[0][7] = WROOK;
        Game[1][7] = WKNIGHT;
        Game[2][7] = WBISHOP;
        Game[3][7] = WQUEEN;
        Game[4][7] = WKING;
        Game[5][7] = WBISHOP;
        Game[6][7] = WKNIGHT;
        Game[7][7] = WROOK;
        Game[0][6] = WPAWN;
        Game[1][6] = WPAWN;
        Game[2][6] = WPAWN;
        Game[3][6] = WPAWN;
        Game[4][6] = WPAWN;
        Game[5][6] = WPAWN;
        Game[6][6] = WPAWN;
        Game[7][6] = WPAWN;
}
void removeThePiece(int x, int y)
{
        if ((x + y) % 2 == 0)
        {
                Game[x][y] = SWHITE;
        }
        else
        {
                Game[x][y] = SBLACK;
        }
}

void ReverseGridColor(int g_x, int g_y)
{
        if (Game[g_x][g_y] == SBLACK)
        {
                Game[g_x][g_y] = SWHITE;
        }
        else
        {
                Game[g_x][g_y] = SBLACK;
        }
}

enum GRID promote(ChessPiece *piece, enum GRID GRID){
  promWin = gtk_dialog_new_with_buttons ("Promote Piece", GTK_WINDOW(window), GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT, "Queen", QUEEN, "Rook", ROOK, "Knight", KNIGHT, "Bishop", BISHOP, NULL);
  gint result = gtk_dialog_run (GTK_DIALOG (promWin));
  switch (result){
    case QUEEN:
      *promoted =  QUEEN;
      break;
    case ROOK:
      *promoted =  ROOK;
      break;
    case KNIGHT:
      *promoted =  KNIGHT;
      break;
    case BISHOP:
      *promoted =  BISHOP;
      break;
  }
  gtk_widget_destroy (promWin);

  switch(*promoted){
    case QUEEN:
      if(GRID <= 13 && GRID >= 9){
        GRID = WQUEEN;
      }
      else{
        GRID = BQUEEN;
      }
      break;
    case KNIGHT:
      if(GRID <= 13 && GRID >= 9){
        GRID = WKNIGHT;
      }
      else{
        GRID = BKNIGHT;
      }
      break;
    case ROOK:
      if(GRID <= 13 && GRID >= 9){
        GRID = WROOK;
      }
      else{
        GRID = BROOK;
      }
      break;
    case BISHOP:
      if(GRID <= 13 && GRID >= 9){
        GRID = WBISHOP;
      }
      else{
        GRID = BBISHOP;
      }
      break;
  }

  piece->Type = *promoted;
  return GRID;
}

void MoveThePiece(int g_x, int g_y, int oldX, int oldY, Board *gameBoard)
{
        int rVal = -1;
        //check valid move input parameters
        assert(gameBoard);
        assert(gameBoard->chessBoard);
        assert(gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece);

        rVal = checkValidMove(gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece, gameBoard->chessBoard[g_x][7 - g_y], gameBoard);
        char move[SLEN];
        int gameOver = 0;
        if ((rVal != 0) && (getGameTurn(gameBoard) == gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece->color))
        {
                char *pie;
                char *cap = "";
                char *capPiece = "";
                if (rVal == 2)
                {
                        if(//movePutsKingInCheck(gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece, gameBoard->chessBoard[g_x][7 - g_y], gameBoard) == 1){
                          gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece->Type == KING){
                          gameOver = 1;
                        }
                        cap = "CAPTURE\n";
                }
                Game[g_x][g_y] = Game[oldX][oldY];
                moveChessPiece(gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece, gameBoard->chessBoard[g_x][7 - g_y], gameBoard);
                removeThePiece(oldX, oldY);

                switch (gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece->Type)
                {
                case PAWN:
                        pie = "PAWN";
                        break;
                case ROOK:
                        pie = "ROOK";
                        break;
                case KNIGHT:
                        pie = "KNIGHT";
                        break;
                case BISHOP:
                        pie = "BISHOP";
                        break;
                case KING:
                        pie = "KING";
                        break;
                case QUEEN:
                        pie = "QUEEN";
                        break;
                }
                if((set == 0 && getGameTurn(gameBoard) == WHITE) || (set == 1 && getGameTurn(gameBoard) == BLACK))
                  sprintf(move, "WHITE %s\n(%d, %d) -> (%d, %d)\n%s", pie, oldX, 7 - oldY, g_x, 7 - g_y, cap);
                else
                  sprintf(move, "BLACK %s\n(%d, %d) -> (%d, %d)\n%s", pie, oldX, 7 - oldY, g_x, 7 - g_y, cap);

                if (validPawnPromotion(gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece) == 1)
                {
                        Game[g_x][g_y] = promote(gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece, Game[g_x][g_y]);
                }

                changeGameTurn(gameBoard);
        }
        else if ((rVal != 0) && (getGameTurn(gameBoard) != gameBoard->chessBoard[oldX][7 - oldY]->thisSquaresPiece->color))
        {
              sprintf(move, "It's not your move.\n");
        }
        else if (rVal == 0)
        {
                sprintf(move, "Invalid Move, try again.\n(%d, %d) -> (%d, %d)\n", oldX, 7 - oldY, g_x, 7 - g_y);
        }
        gtk_text_buffer_insert(history, &iter, move, -1);
        fputs(move, mLog);
        gtk_text_view_scroll_to_mark (GTK_TEXT_VIEW(moveHistory),gtk_text_buffer_get_insert (history), 0.0, TRUE, 0.5, 0.5);
        if(gameOver == 1){
          char *msg;
          if((set == 0 && gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece->color == set) || (set == 1 && gameBoard->chessBoard[g_x][7 - g_y]->thisSquaresPiece->color != set)){
            msg = WIN_MESSAGE;

          }
          else{
            msg = LOSS_MESSAGE;
          }
          gtk_text_buffer_insert(history, &iter, msg, -1);
          fputs(msg, mLog);
          GtkWidget *quitWin = gtk_message_dialog_new (GTK_WINDOW(window), GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_OTHER, GTK_BUTTONS_CLOSE, msg);
          gint result = gtk_dialog_run (GTK_DIALOG (quitWin));
          gtk_main_quit();
          gtk_widget_destroy (quitWin);
        }
}

void DrawBoard()
{
        int i, j;

        for (i = 0; i < 8; i++)
        {
                for (j = 0; j < 8; j++)
                {
                        switch (Game[i][j])
                        {
                        case SBLACK:
                                chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/Bsquare.jpg");
                                break;
                        case SWHITE:
                                chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/Wsquare.jpg");
                                break;
                        case BKING:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bKoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bKoB.png");
                                }
                                break;
                        case BQUEEN:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bQoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bQoB.png");
                                }
                                break;

                        case BROOK:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bRoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bRoB.png");
                                }

                                break;

                        case BKNIGHT:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bNoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bNoB.png");
                                }
                                break;

                        case BPAWN:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bPoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bPoB.png");
                                }
                                break;
                        case BBISHOP:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bBoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/bBoB.png");
                                }
                                break;
                        case WKING:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wKoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wKoB.png");
                                }
                                break;
                        case WQUEEN:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wQoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wQoB.png");
                                }
                                break;

                        case WROOK:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wRoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wRoB.png");
                                }
                                break;

                        case WKNIGHT:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wNoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wNoB.png");
                                }

                                break;

                        case WPAWN:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wPoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wPoB.png");
                                }
                                break;
                        case WBISHOP:
                                if ((i + j) % 2 == 0)
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wBoW.png");
                                }
                                else
                                {
                                        chess_icon = gtk_image_new_from_file("./src/GUI_Prototype/chess_icon/wBoB.png");
                                }
                                break;

                        default:
                                break;
                        }
                        gtk_table_attach(GTK_TABLE(table), chess_icon, i, i + 1, j, j + 1, GTK_FILL, GTK_FILL, 0, 0);
                }
        }
}

void CoordToGrid(int c_x, int c_y, int *g_x, int *g_y)
{
        *g_x = (c_x - GBOARD_BORDER) / GSQUARE_SIZE;
        *g_y = ((c_y - GBOARD_BORDER) / GSQUARE_SIZE);
}

static gboolean
on_delete_event(GtkWidget *widget,
                GdkEvent *event,
                gpointer data)
{
        /* If you return FALSE in the "delete_event" signal handler,
   * GTK will emit the "destroy" signal. Returning TRUE means
   * you don't want the window to be destroyed.
   *
   * This is useful for popping up 'are you sure you want to quit?'
   * type dialogs.
   */

        gtk_main_quit();
        return TRUE;
}

gint area_click(GtkWidget *widget,
                GdkEvent *event,
                Board *thisGameBoard)
{
        static int i = -1;
        static int oldX, oldY;
        int x1, y1;
        //char arary words of size max_msglen which is defined in the header file length defined as 100
        char words[MAX_MSGLEN];
        //initialize int variables for the coordinantes
        int coord_x, coord_y, grid_x, grid_y;
        //create struct pointer BOARD, SQUARE
        struct Game *chess_board;
        struct SQUARE *chess_piece;
        struct SQUARE *piece_dest;
        //A set of bit-flags to indicate the state of modifier keys and mouse buttons in various event types. Typical modifier keys are Shift, Control, Meta, Super, Hyper, Alt, Compose, Apple, CapsLock or ShiftLock.
        GdkModifierType gState;
        //Obtains the current pointer position and modifier state. The position is given in coordinates relative to the upper left corner of window
        //x
        //
        //return location for X coordinate of pointer or NULL to not return the X coordinate
        //y
        //
        //return location for Y coordinate of pointer or NULL to not return the Y coordinate.
        //mask
        //
        //return location for modifier mask or NULL to not return the modifier mask.

        gdk_window_get_pointer(widget->window, &coord_x, &coord_y, &gState);
        //chnages coordinates to grid coordinates
        CoordToGrid(coord_x, coord_y, &grid_x, &grid_y);
        //prints to screen
        //printf("coord_x = %d, coord_y = %d, grid_x = %d, grid_y = %d \n", coord_x, coord_y, grid_x, grid_y);
        //function moveTheKing to different positiion on Board
        if (coord_x < 10 || coord_x > 410 || coord_y < 10 || coord_y > 410)
        {
                printf("Clicked outside of the chess board\n");
                if(opp == 1){
                  MoveListNode *oppMove = AImediummove(thisGameBoard->player2, thisGameBoard);
                  assert(oppMove);
                  int nOldX = getSquareXPos(oppMove->startSquare);
                  int nOldY= getSquareYPos(oppMove->startSquare);
                  int g_x = getSquareXPos(oppMove->endSquare);
                  int g_y = getSquareYPos(oppMove->endSquare);
                  MoveThePiece(g_x, 7 -  g_y, nOldX, 7 - nOldY, thisGameBoard);
                  deleteMoveList(oppMove->list);
                }
        }
        else if (i == 2)
        {
                MoveThePiece(grid_x, grid_y, oldX, oldY, thisGameBoard);
                i = -1;
        }

        else if (Game[grid_x][grid_y] != SBLACK && Game[grid_x][grid_y] != SWHITE)
        {
                printf("Piece Selected!\n");
                i = 2;
                oldX = grid_x;
                oldY = grid_y;
                return TRUE;
        }

        else
        {
                i = -1;
        }

        gtk_container_remove(GTK_CONTAINER(window), fixed);
        table = gtk_table_new(8, 8, TRUE);
        gtk_widget_set_size_request(table, GBOARD_WIDTH, GBOARD_HEIGHT);
        DrawBoard();

        /*set fixed*/

        fixed = gtk_fixed_new();
        gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0);
        gtk_container_add(GTK_CONTAINER(window), fixed);
        gtk_widget_show_all(window);

        return TRUE;
}

int main(int argc,
         char *argv[])
{
        char str[GMAX_MSGLEN];

        gtk_init(&argc, &argv);
        //resets board to default mode

        state = fopen("state.txt", "r");
        fscanf(state, "opp%dset%d", &opp, &set);
        fclose(state);
        //opp = 0;
        //set = 0;
        current.opponent = opp;
        current.set_color = set;

        Color player1Color, player2Color;
        PlayerType player2Type;

        if (set == 0)
        {
                player1Color = WHITE;
                player2Color = BLACK;
        }
        else
        {
                player1Color = BLACK;
                player2Color = WHITE;
        }

        if (opp == 0)
        {
                player2Type = HUMAN;
        }
        else
        {
                player2Type = COMPUTER;
        }

        Player *player1 = createPlayer(WHITE, HUMAN);
        Player *player2 = createPlayer(BLACK, player2Type);

        Board *thisGameBoard = createGameBoard(player1Color);
        populateGameBoard(thisGameBoard);
        fillPlayerPieces(player1, thisGameBoard);
        fillPlayerPieces(player2, thisGameBoard);
        thisGameBoard->player1 = player1;
        thisGameBoard->player2 = player2;

        // ResetBoard();

        /*create a new window */
        //simply new window
        window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        hisWin = gtk_window_new(GTK_WINDOW_POPUP);
        //request for window to be size of windowWidth and windowHeight defined in the header file
        gtk_widget_set_size_request(window, GWINDOW_WIDTH, GWINDOW_HEIGHT);
        //set boarder width by window border defined in the header file
        gtk_container_set_border_width(GTK_CONTAINER(window), GWINDOW_BORDER);
        gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
        gtk_widget_set_size_request(hisWin, GWINDOW_WIDTH / 2, GWINDOW_HEIGHT / 2);
        //set boarder width by window border defined in the header file
        gtk_container_set_border_width(GTK_CONTAINER(hisWin), GWINDOW_BORDER);
        gtk_window_set_position(GTK_WINDOW(hisWin), GTK_WIN_POS_CENTER);
        gtk_window_move(GTK_WINDOW(hisWin), 400, 400);
        //gtk_window_set_transient_for(GTK_CONTAINER(hisWin), GTK_CONTAINER(window));
        //gtk_window_set_position(GTK_WINDOW(hisWin), GTK_WIN_POS_CENTER);
        //gtk_window_move(GTK_WINDOW(hisWin), 400, 400);
        gtk_window_set_transient_for(GTK_WINDOW(hisWin), GTK_WINDOW(window));
        gtk_window_set_title(GTK_WINDOW(window), "Let's play Chess!");
        gtk_window_set_title(GTK_WINDOW(hisWin), "Move History\n");

        // make window size fixed
        gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

        /*register event handlers*/
        //when the exit icon is pressed
        g_signal_connect(window, "delete_event", G_CALLBACK(on_delete_event), NULL);

        //set events for button press
        //Sets the event mask (see GdkEventMask) for a widget
        //The event mask determines which events a widget will receive
        gtk_widget_set_events(window, GDK_BUTTON_PRESS_MASK);
        //when a button is pressed call area_click
        //Signal will be emitted when a button (typically from a mouse) is pressed
        g_signal_connect(window, "button_press_event", G_CALLBACK(area_click), thisGameBoard);

        /*create a table and draw the board*/
        table = gtk_table_new(8, 10, TRUE);
        gtk_widget_set_size_request(table, GBOARD_WIDTH, GBOARD_HEIGHT);
        InitBoard(player2, thisGameBoard);
        DrawBoard();

        fixed = gtk_fixed_new();
        gtk_fixed_put(GTK_FIXED(fixed), table, 0, 0);
        gtk_container_add(GTK_CONTAINER(window), fixed);

        moveHistory = gtk_text_view_new();
        scrollView = gtk_scrolled_window_new(NULL, NULL);
        history = gtk_text_view_get_buffer(GTK_TEXT_VIEW(moveHistory));
        gtk_text_buffer_get_iter_at_offset(history, &iter, 0);
        gtk_text_buffer_insert(history, &iter, "History of Moves:\n", -1);
        gtk_text_view_set_editable(GTK_TEXT_VIEW(moveHistory), FALSE);
        gtk_container_add(GTK_CONTAINER(scrollView), moveHistory);
        gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrollView), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
        gtk_container_add(GTK_CONTAINER(hisWin), scrollView);

        promoted = malloc(sizeof(int));
        assert(promoted);

        mLog = fopen("bin/GameLogs/GameLog.txt", "w");

        /*show the window*/
        gtk_widget_show_all(window);
        gtk_widget_show_all(hisWin);


        gtk_main();

        deletePlayer(player1);
        deletePlayer(player2);
        free(promoted);
        deleteGameBoard(thisGameBoard);
        fclose(mLog);

        return 0;
}

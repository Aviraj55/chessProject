//source file for player functions

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <time.h>
#include "player.h"
#include "pieces.h"
#include "moveList.h"
#include "square.h"

Player *createPlayer(Color color, PlayerType type)
{
  Player *newPlayer = malloc(sizeof(Player));

  newPlayer->playerColor = color;
  newPlayer->type = type;
  newPlayer->isInCheckmate = 0; //default a Player to not be in checkmate when it is created

  return newPlayer;
}

void deletePlayer(Player *player)
{
  free(player);
}

void deletePlayerPiece(ChessPiece *piece, Player *player)
{

  piece->square = NULL;

  for (int i = 0; i < (sizeof(player->playerPieces)) / sizeof(player->playerPieces[0]); i++)
  {
    if (piece == player->playerPieces[i])
      player->playerPieces[i] = NULL;
  }

  deleteChessPiece(piece);
}

void fillPlayerPieces(Player *player, Board *gameBoard)
{
  if (player->playerColor == WHITE)
  {
    for (int i = 0; i < 8; ++i)
    {
      player->playerPieces[i] = getChessPiece(gameBoard->chessBoard[i][0]);
      player->playerPieces[8 + i] = getChessPiece(gameBoard->chessBoard[i][1]);
    }
    player->playerKing = getChessPiece(gameBoard->chessBoard[4][0]);
  }

  else if (player->playerColor == BLACK)
  {
    for (int i = 0; i < 8; ++i)
    {
      player->playerPieces[i] = getChessPiece(gameBoard->chessBoard[i][7]);
      player->playerPieces[8 + i] = getChessPiece(gameBoard->chessBoard[i][6]);
    }
    player->playerKing = getChessPiece(gameBoard->chessBoard[4][7]);
  }
}

MoveList *getAllPossibleMoves(Player *player, Board *gameBoard)
{
  MoveList *possibleMoveList = createMoveList();
  for (int i = 0; i < sizeof(player->playerPieces) / sizeof(player->playerPieces[0]); ++i)
  {
    if (player->playerPieces[i] == NULL)
    {
      continue;
    }
    else
    {
      appendMoveLists(possibleMoveList, getValidMoves(player->playerPieces[i], gameBoard));
    }
  }
  return possibleMoveList;
}

ChessPiece *getOpponentPlayerKing(ChessPiece *piece, Board *gameBoard)
{
  ChessPiece *playerKing;
  for (int i = 0; i < 8; ++i)
  {
    for (int j = 0; j < 8; ++j)
    {
      if (getChessPiece(gameBoard->chessBoard[i][j]) == NULL)
      {
        continue;
      }
      if ((getChessPiece(gameBoard->chessBoard[i][j])->Type == KING) && (getChessPiece(gameBoard->chessBoard[i][j])->color != piece->color))
      {
        playerKing = getChessPiece(gameBoard->chessBoard[i][j]);
        return playerKing;
      }
    }
  }
  return NULL;
}

/*
piece is the piece to move
 endSquare is the endSquare of the current move to verify if it will put the king in check on the next turn
 gameBoard is the current state of the game board
 */
int movePutsKingInCheck(ChessPiece *piece, Square *endSquare, Board *gameBoard)
{
  ChessPiece *originalEndSquarePiece; //keep track of the piece that was on the end square before trying the move
  if (endSquare->thisSquaresPiece != NULL)
  {
    originalEndSquarePiece = endSquare->thisSquaresPiece;
  }
  else
  {
    originalEndSquarePiece = NULL;
  }

  ChessPiece *pieceCopy = createChessPiece(piece->color, piece->Type, endSquare); //creates a copy of the piece at the new location (endsquare)
  ChessPiece *opponentKing = getOpponentPlayerKing(piece, gameBoard);

  if (checkValidMove(pieceCopy, getPiecesSquare(opponentKing), gameBoard) != 0)
  {
    deleteChessPiece(pieceCopy);
    endSquare->thisSquaresPiece = originalEndSquarePiece;
    return 1;
  }

  endSquare->thisSquaresPiece = originalEndSquarePiece;
  deleteChessPiece(pieceCopy);
  return 0;
}

MoveListNode *AImediummove(Player *player, Board *gameBoard)
{
  if (player->type == COMPUTER)
  {
    MoveList *moveset1 = getAllPossibleMoves(player, gameBoard);
    assert(moveset1);
    MoveListNode *current = moveset1->head;
    MoveListNode *next;
    assert(current);
    assert(next);

    //check first if there is a possiblity to put opponent's king in check, if so move then break
    for (int j = 0; j < (moveset1->length); j++)
    {
      next = current->nextNode;
      if (movePutsKingInCheck(current->startSquare->thisSquaresPiece, current->endSquare, gameBoard) == 1) //returns 1 when puts in check
      {
        //printf("hi3\n");
        //moveChessPiece(current->startSquare->thisSquaresPiece, current->endSquare, gameBoard);
        return current; //don't want more moves
      }
      current = next;
    }
    MoveList *moveset2 = createMoveList();
    current = moveset1->head;
    time_t t;
    int selection;
    srand((unsigned)time(&t));
    for (int i = 0; i < (moveset1->length); i++) //add all the moves to a new list if it will result in a capture
    {
      next = current->nextNode;
      if (current->endSquare->thisSquaresPiece != NULL)
      {
        if (checkValidMove(current->startSquare->thisSquaresPiece, current->endSquare, gameBoard) == 2)
        {
          appendMove(current->startSquare, current->endSquare, moveset2);
        }
      }
      current = next;
    }
    if (moveset2->length == 0) //if list is empty then just random from whole list
    {
      //random from moveset1 list
      printf("hi\n");
      MoveListNode *currents = moveset1->head;
      MoveListNode *nexts;
      selection = rand() % (moveset1->length);
      for (int k = 0; k < selection; k++)
      {
        nexts = currents->nextNode;
        currents = nexts;
      }

      //moveChessPiece(currents->startSquare->thisSquaresPiece, currents->endSquare, gameBoard);
      return currents;
    }
    else //if moves are in list randomize from there
    {
      //random from moveset list
      printf("hi2\n");
      MoveListNode *currents = moveset2->head;
      MoveListNode *nexts;
      selection = rand() % (moveset2->length);
      for (int k = 0; k < selection; k++)
      {
        nexts = currents->nextNode;
        currents = nexts;
      }

      printf("hi\n");
      //moveChessPiece(currents->startSquare->thisSquaresPiece, currents->endSquare, gameBoard);
      return currents;
    }
  }
  return NULL;
}

MoveListNode *AIeasymove(Player *player, Board *gameBoard)
{
  if (player->type == COMPUTER)
  {
    //random through movelist
    time_t t;
    int selection;
    srand((unsigned)time(&t));
    MoveList *moveset = getAllPossibleMoves(player, gameBoard);
    MoveListNode *current = moveset->head;
    MoveListNode *next;

    for (int j = 0; j < (moveset->length); j++) //prioritize king capture
    {
      next = current->nextNode;
      if (movePutsKingInCheck(current->startSquare->thisSquaresPiece, current->endSquare, gameBoard) == 1) //returns 1 when puts in check
      {
        moveChessPiece(current->startSquare->thisSquaresPiece, current->endSquare, gameBoard);
        return current; //don't keep looking for moves
      }
      current = next;
    }

    selection = rand() % (moveset->length);
    MoveListNode *currents = moveset->head;
    MoveListNode *nexts;
    for (int i = 0; i < selection; i++)
    {
      nexts = currents->nextNode;
      currents = nexts;
    }
    moveChessPiece(currents->startSquare->thisSquaresPiece, currents->endSquare, gameBoard);
    return currents;
  }
  return NULL;
}

# Kings of Chess (Team15 Spring 2020)

Kings of Chess is a chess application that allows you to play against another human or against a computer opponent.

## Installation

Download the Chess_Kings.tar.gz file and use [tar](https://www.gnu.org/software/tar/) to extract the Kings of Chess files.

```bashk
$ gtar -xvzf Chess_Kings.tar.gz
```

## Usage

After extracting the files, run the makefile once you're in the directory created by extracting the files to compile and run the program

```bash
~/Team15 $ make run
```

## Gameplay

When you first enter the game you will encounter the main menu screen where you have the option to start a new game or go to a help screen. To go start playing, click "New Game" then click on whether you want to play vs a human or computer, then click the color you want to be. After selecting your opponent and color, click "Start Game" and your game will be started. From here you can play Kings of Chess in all its glory!
